# Heart disease prediction and recommendation: code and data

Data: https://archive.ics.uci.edu/dataset/45/heart+disease (Janosi, Steinbrunn, Pfisterer, Detrano; doi 10.24432/C52P4X).

1. Put the four UCI processed files in data/raw/ and run `python build_dataset.py` (or use data/heart_disease_918.csv, which is the output).
2. `python nested.py LR,SVM,kNN,GNB,DT,RF,GB,XGB full` runs 10x5 nested cross-validation (inner 3-fold grid search; imputation and scaling are fitted inside each fold).
   Use `noca_thal` or `noca_thal_slope` as the last argument for the reduced-feature runs, and `LRll,LRni full` for the logistic regression variants.
3. `python loco.py` and `python loco2.py` run leave-one-centre-out validation.
4. `python analyze.py`, `python ablate_shap.py`, `python figs2.py` produce the summary tables, SHAP and ablation results, and figures.
5. `python make_cases.py`, `python drafts.py`, `python run_checks2.py` build the advice-module cases, the drafts, and the automatic safety checks.
results/reviewer_rating_sheet.csv is the sheet for clinician ratings of the generated advice.

6. `python generate_advice.py` (needs DEEPSEEK_API_KEY) generates the advice drafts with the DeepSeek API from the prompts and runs the safety checks.
7. After clinicians fill results/reviewer_rating_sheet.csv, `python summarise_ratings.py` produces the rating summary.
data/heart_clean.csv is the imputed version of the same 918 records (identical observed values; missing values filled once on the whole file).
8. `python run_checks_deepseek.py` runs the nine checks and the injection test on results/drafts_deepseek.json and writes results/llm_results_deepseek.json.
9. `python audit_outputs.py` audits the 100 stored outputs of the prototype (results/patient_data.json) and writes results/audit_results.json.
