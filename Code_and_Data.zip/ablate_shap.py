import pickle, json, numpy as np, pandas as pd
from collections import Counter
from scipy import stats
from common import *
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score
import shap
raw,D=load(); X=D[FEATS].values; y=D.target.values
Rlr=pickle.load(open('res_full_LRll.pkl','rb')); Rx=pickle.load(open('res_full_XGB.pkl','rb'))
modalC=float(Counter(p['m__C'] for p in Rlr['params']).most_common(1)[0][0])
mx=json.loads(Counter(json.dumps(p,sort_keys=True) for p in Rx['params']).most_common(1)[0][0])
print('modal C',modalC,'modal xgb',mx)
def lrpipe(C): return Pipeline([('imp',SimpleImputer(strategy='median',add_indicator=True)),('sc',StandardScaler()),('m',LogisticRegression(C=C,max_iter=2000))])
def cvauc(cols):
    aucs=[]
    for r in range(10):
        for tr,te in StratifiedKFold(5,shuffle=True,random_state=100+r).split(X,y):
            p=lrpipe(modalC).fit(X[tr][:,cols],y[tr]).predict_proba(X[te][:,cols])[:,1]; aucs.append(roc_auc_score(y[te],p))
    return np.array(aucs)
allc=list(range(13)); base=cvauc(allc); ab={'full':[base.mean(),base.std(ddof=1)]}
for j,f in enumerate(FEATS):
    a=cvauc([c for c in allc if c!=j]); d=base-a; v=d.var(ddof=1); t=d.mean()/np.sqrt((1/50+.25)*v); p=2*stats.t.sf(abs(t),49)
    ab[f]=dict(auc=float(a.mean()),delta=float(-d.mean()),sd=float(d.std(ddof=1)),p=float(p))
    print(f,round(a.mean(),4),round(-d.mean(),4),round(p,3),flush=True)
# ---- SHAP
lr=lrpipe(modalC).fit(X,y)
xg=Pipeline([('imp',SimpleImputer(strategy='median',add_indicator=True)),('sc',StandardScaler()),('m',XGBClassifier(subsample=0.8,colsample_bytree=0.8,eval_metric='logloss',n_jobs=1,random_state=0,verbosity=0,n_estimators=int(mx['m__n_estimators']),learning_rate=float(mx['m__learning_rate']),max_depth=int(mx['m__max_depth'])))]).fit(X,y)
imp=lr.named_steps['imp']; ind=list(imp.indicator_.features_); names=FEATS+[FEATS[i]+'_missing' for i in ind]
Z=lr[:-1].transform(X)
el=shap.LinearExplainer(lr.named_steps['m'],shap.maskers.Independent(Z,max_samples=len(Z))); sv_lr=el.shap_values(Z)
coefs=lr.named_steps['m'].coef_[0]; contrib=coefs*(Z-Z.mean(0)); print('max |SHAP-linear contribution| diff',float(np.abs(sv_lr-contrib).max()))
Zx=xg[:-1].transform(X); sv_x=shap.TreeExplainer(xg.named_steps['m']).shap_values(Zx)
def base_imp(sv):
    m=np.abs(sv).mean(0); d={}
    for i,nm in enumerate(names): d[nm.replace('_missing','')]=d.get(nm.replace('_missing',''),0)+m[i]
    return d
bl,bx=({k:float(v) for k,v in base_imp(sv_lr).items()},{k:float(v) for k,v in base_imp(sv_x).items()})
rho=stats.spearmanr([bl[f] for f in FEATS],[bx[f] for f in FEATS])
print('LR',sorted(bl.items(),key=lambda x:-x[1])[:6]); print('XGB',sorted(bx.items(),key=lambda x:-x[1])[:6]); print('spearman',rho)
json.dump(dict(modalC=modalC,xgb=mx,ablation=ab,shap_lr=bl,shap_xgb=bx,spearman=[float(rho.statistic),float(rho.pvalue)],coef=dict(zip(names,map(float,coefs))),names=names),open('ablate_shap.json','w'),indent=1)
pickle.dump(dict(Z=Z,sv_lr=sv_lr,sv_x=sv_x,names=names),open('shap_arrays.pkl','wb'))
