import pickle, json, numpy as np, pandas as pd, os
from scipy import stats
from common import *
from sklearn.metrics import roc_auc_score, brier_score_loss, confusion_matrix
from sklearn.linear_model import LogisticRegression
raw,D=load(); y=D.target.values; n=len(y)
models=['LR','SVM','kNN','GNB','DT','RF','GB','XGB','LRll','LRni']
R={m:pickle.load(open(f'res_full_{m}.pkl','rb')) for m in models}
S={}
def corrected_t(d,J=50,ratio=0.25):
    d=np.asarray(d); v=d.var(ddof=1)
    if v==0: return 0.0,1.0
    t=d.mean()/np.sqrt((1/J+ratio)*v); return t,2*stats.t.sf(abs(t),J-1)
# ---- performance summary
perf={}
for m in models:
    df=pd.DataFrame(R[m]['rows']); perf[m]={k:[df[k].mean(),df[k].std(ddof=1)] for k in ['auc','f1','acc','prec','rec','spec','brier']}
S['perf']=perf
S['paired']={}
for m in models:
    if m=='LR': continue
    a=pd.DataFrame(R['LR']['rows']); b=pd.DataFrame(R[m]['rows'])
    out={}
    for k in ['auc','f1','brier']:
        d=(a[k]-b[k]).values; t,p=corrected_t(d); out[k]=dict(diff=float(d.mean()),t=float(t),p=float(p),sd=float(d.std(ddof=1)))
    S['paired'][m]=out
# best params frequency
S['params']={}
for m in models:
    from collections import Counter
    c=Counter(json.dumps(p,sort_keys=True) for p in R[m]['params']); S['params'][m]=c.most_common(3)
# ---- calibration
def logit(p): p=np.clip(p,1e-4,1-1e-4); return np.log(p/(1-p))
def ece(p,yt,bins=10):
    q=np.quantile(p,np.linspace(0,1,bins+1)); q[-1]+=1e-9; idx=np.digitize(p,q[1:-1]); e=0
    for b in range(bins):
        mk=idx==b
        if mk.sum(): e+=mk.mean()*abs(p[mk].mean()-yt[mk].mean())
    return e
cal={}; rel={}
for m in models:
    oof=R[m]['oof']; pbar=oof.mean(0)
    P=oof.reshape(-1); Y=np.tile(y,oof.shape[0])
    lr=LogisticRegression(C=1e6,max_iter=1000).fit(logit(P).reshape(-1,1),Y)
    cal[m]=dict(brier=float(np.mean([brier_score_loss(y,oof[r]) for r in range(oof.shape[0])])),ece=float(np.mean([ece(oof[r],y) for r in range(oof.shape[0])])),slope=float(lr.coef_[0,0]),intercept=float(lr.intercept_[0]),auc_bar=float(roc_auc_score(y,pbar)))
    q=np.quantile(P,np.linspace(0,1,11)); q[-1]+=1e-9; idx=np.digitize(P,q[1:-1])
    rel[m]=[(float(P[idx==b].mean()),float(Y[idx==b].mean()),int((idx==b).sum())) for b in range(10)]
S['cal']=cal; S['rel']=rel
# ---- risk bands from pooled OOF of LR and XGB
def bands(m):
    oof=R[m]['oof']; P=oof.reshape(-1); Y=np.tile(y,oof.shape[0])
    ts=np.linspace(0.05,0.95,91); best_low=None; best_high=None
    for t in ts:
        lo=P<t
        if lo.sum()>=0.05*len(P):
            npv=1-Y[lo].mean()
            if npv>=0.90: best_low=t
    for t in ts[::-1]:
        hi=P>=t
        if hi.sum()>=0.05*len(P):
            ppv=Y[hi].mean()
            if ppv>=0.85: best_high=t
    # fall back if not found
    return best_low,best_high
S['bands']={}
for m in ['LR','LRll','XGB','RF']:
    lo,hi=bands(m); pbar=R[m]['oof'].mean(0); res=dict(low=lo,high=hi)
    if lo is not None and hi is not None:
        grp=np.where(pbar<lo,'low',np.where(pbar>=hi,'high','moderate'))
        res['bands']={g:dict(n=int((grp==g).sum()),obs=float(y[grp==g].mean()),mean_pred=float(pbar[grp==g].mean())) for g in ['low','moderate','high']}
    S['bands'][m]=res
# youden
for m in ['LRll']:
    P=R[m]['oof'].reshape(-1); Y=np.tile(y,10); best=(0,0.5)
    for t in np.linspace(0.05,0.95,91):
        pr=P>=t; tp=(pr&(Y==1)).sum(); tn=(~pr&(Y==0)).sum(); j=tp/(Y==1).sum()+tn/(Y==0).sum()-1
        if j>best[0]: best=(float(j),float(t))
    S['youden_LRll']=best
# ---- subgroup (core model decided later: compute for LR and XGB)
rng=np.random.default_rng(0)
def boot_auc(yt,p,B=1000):
    if len(np.unique(yt))<2: return (np.nan,np.nan,np.nan)
    a=roc_auc_score(yt,p); vals=[]
    for _ in range(B):
        i=rng.integers(0,len(yt),len(yt))
        if len(np.unique(yt[i]))<2: continue
        vals.append(roc_auc_score(yt[i],p[i]))
    return a,np.percentile(vals,2.5),np.percentile(vals,97.5)
age=D.age.values; sex=D.sex.values; cen=D.centre.values
groups={'sex':{'female':sex==0,'male':sex==1},'age':{'<50':age<50,'50-59':(age>=50)&(age<60),'>=60':age>=60},'centre':{c:cen==c for c in ['cleveland','hungarian','switzerland','va']}}
S['sub']={}
for m in ['LR','LRll','XGB']:
    pbar=R[m]['oof'].mean(0); S['sub'][m]={}
    for gname,gs in groups.items():
        for g,mk in gs.items():
            yt=y[mk]; p=pbar[mk]; pr=(p>=.5).astype(int)
            tn,fp,fn,tp=confusion_matrix(yt,pr,labels=[0,1]).ravel()
            a,l,u=boot_auc(yt,p)
            S['sub'][m][f'{gname}:{g}']=dict(n=int(mk.sum()),prev=float(yt.mean()),auc=a,lo=l,hi=u,sens=float(tp/max(tp+fn,1)),spec=float(tn/max(tn+fp,1)),brier=float(brier_score_loss(yt,p)),meanp=float(p.mean()))
# ---- reduced feature sets
S['reduced']={}
for var in ['noca_thal','noca_thal_slope']:
    S['reduced'][var]={}
    for m in models:
        f=f'res_{var}_{m}.pkl'
        if not os.path.exists(f): continue
        r=pickle.load(open(f,'rb')); df=pd.DataFrame(r['rows']); full=pd.DataFrame(R[m]['rows'])
        d=(df['auc']-full['auc']).values; t,p=corrected_t(d)
        S['reduced'][var][m]=dict(auc=[df.auc.mean(),df.auc.std(ddof=1)],f1=[df.f1.mean(),df.f1.std(ddof=1)],brier=[df.brier.mean(),df.brier.std(ddof=1)],acc=[df.acc.mean(),df.acc.std(ddof=1)],dauc=float(d.mean()),p=float(p))
json.dump(S,open('summary.json','w'),indent=1,default=float)
print(json.dumps({k:S[k] for k in ['perf']},indent=0,default=float)[:3000])
