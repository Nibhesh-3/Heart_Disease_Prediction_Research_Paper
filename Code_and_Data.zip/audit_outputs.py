"""Audit of the stored outputs of the prototype (results/patient_data.json): rule-based checks plus manual verification of flagged items."""
import json, re, sys, numpy as np, pandas as pd
from llm_module import fk_grade, DRUGS
path=sys.argv[1] if len(sys.argv)>1 else 'results/patient_data.json'
df=pd.DataFrame(json.load(open(path))); T=df.clinical_guidance
F=['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal']
def pct(t):
    m=re.search(r'(\d+(?:\.\d+)?)\s?%',t); return float(m.group(1)) if m else np.nan
p=T.map(pct)
R={}
R['n']=len(df); R['unique_inputs']=int(df[F].drop_duplicates().shape[0]); R['top_user_records']=int(df.user_id.value_counts().iloc[0]); R['names_stored']=int(df.name.notna().sum())
R['class1']=int((df.prediction_code==1).sum()); R['class0']=int((df.prediction_code==0).sum())
R['states_probability']=int(p.notna().sum())
r=df.dropna(subset=['risk_score']); R['risk_score_rows']=len(r); R['risk_score_equals_text']=int((abs(r.risk_score*100-p[r.index])<0.06).sum())
w=T.str.split().str.len(); R['words_mean']=float(w.mean()); R['words_min']=int(w.min()); R['words_max']=int(w.max()); R['fk_mean']=float(np.mean([fk_grade(t) for t in T]))
R['uncertainty_or_disclaimer']=int(T.str.contains(r'estimate|uncertain|may be wrong|not a substitute|disclaimer|should not replace',case=False).sum())
R['names_medicine']=int(T.str.contains(DRUGS+r'|medication|therapy|antiplatelet|anticoag',case=False,regex=True).sum())
R['lifestyle_content']=int(T.str.contains(r'lifestyle|\bdiet|smok|physical activity|weight (loss|management)|regular exercise|exercise program',case=False).sum())
R['escalation_words']=int(T.str.contains(r'urgent|immediate|prompt',case=False).sum())
R['cardiology_referral']=int(T.str.contains(r'cardiolog',case=False).sum())
# verified by reading every flagged text
R['class0_text_high_risk_ids']=[5,29,48,61,72]
R['faith_mentions']={'exang':49,'st_depression':64,'fasting_sugar':27,'vessels':52}; R['faith_contradiction_ids']=[5,59]
# repeated inputs
g=df.groupby(F); dup=g.filter(lambda x:len(x)>1); R['dup_groups']=int(dup.groupby(F).ngroups); R['dup_records']=len(dup)
R['dup_class_conflicts']=int(sum(x.prediction_code.nunique()>1 for _,x in dup.groupby(F)))
big=max((x for _,x in dup.groupby(F)),key=len); R['largest_dup_group']=len(big); R['largest_dup_stated_probs']=sorted(set(np.round(p[big.index].dropna(),2)))
cp3=df[df.cp==3]; R['cp3_n']=len(cp3); R['cp3_typical_angina']=int(T[cp3.index].str.contains('typical angina',case=False).sum())
th=df[T.str.contains('thalass',case=False)]; R['thalass_mentions']=len(th); R['thalass_by_code']={int(k):int(v) for k,v in th.thal.value_counts().sort_index().items()}
json.dump(R,open('audit_results.json','w'),indent=1); print(json.dumps(R,indent=1))
