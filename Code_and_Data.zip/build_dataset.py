"""Build the 918-record analysis file from the four UCI processed files.
Download processed.cleveland.data, processed.hungarian.data, processed.switzerland.data and
processed.va.data from https://archive.ics.uci.edu/dataset/45/heart+disease and place them in ./data/raw/."""
import pandas as pd, numpy as np
COLS=['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal','num']
fr=[]
for c in ['cleveland','hungarian','switzerland','va']:
    d=pd.read_csv(f'data/raw/processed.{c}.data',header=None,names=COLS,na_values=['?','-9','-9.0']); d['centre']=c; fr.append(d)
raw=pd.concat(fr,ignore_index=True)                       # 920 records
D=raw.drop_duplicates(subset=COLS).reset_index(drop=True)  # 918 records (2 exact duplicates removed)
D['chol']=D.chol.replace(0,np.nan); D['trestbps']=D.trestbps.replace(0,np.nan)   # impossible zeros -> missing
D['target']=(D.num>0).astype(int)                          # 0 = no disease, 1 = disease present
D.to_csv('data/heart_disease_918.csv',index=False)         # missing values left empty; imputation happens inside each CV fold
print(D.shape,D.target.value_counts().to_dict())
