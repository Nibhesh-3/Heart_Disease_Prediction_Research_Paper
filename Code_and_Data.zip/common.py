import numpy as np, pandas as pd, warnings
warnings.filterwarnings('ignore')
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
COLS=['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal','num']
FEATS=COLS[:-1]
def load():
    fr=[]
    for c in ['cleveland','hungarian','switzerland','va']:
        d=pd.read_csv(f'data/processed.{c}.data',header=None,names=COLS,na_values=['?','-9','-9.0']); d['centre']=c; fr.append(d)
    raw=pd.concat(fr,ignore_index=True)
    D=raw.drop_duplicates(subset=COLS).reset_index(drop=True)
    D['chol']=D.chol.replace(0,np.nan); D['trestbps']=D.trestbps.replace(0,np.nan)
    D['target']=(D.num>0).astype(int)
    return raw,D
def make(name,feats=None):
    imp=SimpleImputer(strategy='median',add_indicator=(name!='LRni'))
    sc=StandardScaler()
    M={'LR':(LogisticRegression(max_iter=2000),{'m__C':[0.01,0.1,1,10]}),
       'SVM':(SVC(kernel='rbf',probability=True,random_state=0),{'m__C':[0.5,1,4],'m__gamma':['scale',0.01]}),
       'kNN':(KNeighborsClassifier(),{'m__n_neighbors':[5,11,21],'m__weights':['uniform','distance']}),
       'GNB':(GaussianNB(),{'m__var_smoothing':[1e-9,1e-6,1e-3]}),
       'DT':(DecisionTreeClassifier(random_state=0),{'m__max_depth':[3,5,8],'m__min_samples_leaf':[5,10]}),
       'RF':(RandomForestClassifier(n_estimators=200,random_state=0,n_jobs=1),{'m__max_depth':[4,8,None],'m__min_samples_leaf':[1,3]}),
       'GB':(GradientBoostingClassifier(random_state=0),{'m__n_estimators':[100,200],'m__learning_rate':[0.05,0.1],'m__max_depth':[2,3]}),
       'XGB':(XGBClassifier(subsample=0.8,colsample_bytree=0.8,eval_metric='logloss',n_jobs=1,random_state=0,verbosity=0),{'m__n_estimators':[100,200],'m__learning_rate':[0.05,0.1],'m__max_depth':[2,3,4]})}
    M['LRll']=(LogisticRegression(max_iter=2000),{'m__C':[0.03,0.1,0.3,1,3,10]})
    M['LRni']=M['LR']
    est,grid=M[name]
    return Pipeline([('imp',imp),('sc',sc),('m',est)]),grid
