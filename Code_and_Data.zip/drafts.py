import json
D={}
def add(i,summary,factors,diet,activity,lifestyle,seek,disc="This is general health information and not a substitute for advice from a doctor."):
    D[i]=dict(summary=summary,factors=factors,diet=diet,activity=activity,lifestyle=lifestyle,seek_care=seek,disclaimer=disc)
add('C01',"Your estimated chance of heart disease is about 8 percent, which is in the low range. This is only an estimate and it can be wrong.",
 "Being female, having no chest pain during exercise, and a small change on the exercise heart tracing all lowered the estimate.",
 "Keep eating plenty of vegetables, fruit and whole grains. Your cholesterol of 216 is worth watching, so go easy on fried and fatty foods.",
 "Stay active with brisk walking or similar exercise for about 30 minutes on most days.",
 "Do not smoke, keep a healthy weight and try to sleep well. Have your blood pressure and cholesterol checked at routine visits.",
 "No urgent step is needed. If you ever get chest pain, trouble breathing or fainting, seek emergency help.")
add('C02',"Your estimated chance of heart disease is about 16 percent, which is in the low range. This is only an estimate and it can be wrong.",
 "The type of chest pain you reported and your thallium stress test result lowered the estimate, while the number of vessels seen on imaging raised it a little.",
 "Choose meals built around vegetables, beans, fish and whole grains, and cut back on salty and processed foods.",
 "Aim for regular moderate exercise, such as walking or cycling, for about 30 minutes on most days.",
 "Avoid smoking and limit alcohol. Keep a record of your blood pressure, which was 134 at this check.",
 "No urgent step is needed, but mention this result at your next routine visit. Seek emergency help for sudden chest pain or breathlessness.")
add('C03',"Your estimated chance of heart disease is about 6 percent, which is in the low range. This is only an estimate and it can be wrong.",
 "Your type of chest pain, your high maximum heart rate during exercise, and having no chest pain on exercise all lowered the estimate.",
 "A balanced diet with fruit, vegetables and lean protein will help you keep your good numbers.",
 "Keep up regular activity. Mix brisk walking or jogging with some strength work.",
 "Stay away from tobacco and try to manage stress. A yearly check-up is a good habit.",
 "No urgent step is needed. If you get chest pain, trouble breathing or fainting, get emergency help.")
add('C04',"Your estimated chance of heart disease is about 18 percent, which is in the low range. This is only an estimate and it can be wrong.",
 "The type of chest pain you reported, no chest pain during exercise, and a small ST change on the exercise test lowered the estimate.",
 "Your cholesterol of 284 is something to discuss with a doctor. Choose oats, beans, nuts and fish, and reduce fatty and fried food.",
 "Walk or cycle at a moderate pace for about 30 minutes on most days.",
 "Do not smoke and keep a healthy weight. Ask for a cholesterol check at your next routine visit.",
 "No urgent step is needed, but ask a doctor about your cholesterol at a routine visit. Seek emergency help for chest pain or fainting.")
add('C05',"Your estimated chance of heart disease is about 25 percent, which is in the moderate range. This is only an estimate and it can be wrong.",
 "Being female and your type of chest pain lowered the estimate, while your cholesterol of 468 raised it.",
 "Cut down on fried food, full-fat dairy and processed snacks, and add more oats, beans, vegetables and fish.",
 "Start with gentle walking and slowly build up to about 30 minutes on most days.",
 "Do not smoke and limit alcohol. Keep your weight in a healthy range.",
 "Please talk to a doctor about your cholesterol in the coming weeks. Seek emergency help for chest pain, breathlessness or fainting.")
add('C06',"Your estimated chance of heart disease is about 45 percent, which is in the moderate range. This is only an estimate and it can be wrong.",
 "Your thallium stress test result and your fasting blood sugar raised the estimate, while having no chest pain during exercise lowered it.",
 "Choose whole grains, vegetables and lean protein. Limit sugary drinks and sweets, and cut down on salt.",
 "Take regular brisk walks, building up to about 30 minutes on most days.",
 "Do not smoke and manage stress. Your resting blood pressure was 172, so have it checked again.",
 "Please see a doctor in the coming weeks to talk about these results and your blood pressure. Seek emergency help for chest pain or fainting.")
add('C07',"Your estimated chance of heart disease is about 39 percent, which is in the moderate range. This is only an estimate and it can be wrong.",
 "The ST change on your exercise test raised the estimate, while your thallium stress test result and having no chest pain on exercise lowered it.",
 "Eat more vegetables, fruit and whole grains, and limit salty and fried foods.",
 "Walk briskly for about 30 minutes on most days, and stop and rest if you feel unwell.",
 "Do not smoke and keep your weight healthy. Keep a record of your blood pressure.",
 "Please talk to a doctor about the exercise test result in the coming weeks. Seek emergency help for chest pain or fainting.")
add('C08',"Your estimated chance of heart disease is about 31 percent, which is in the moderate range. This is only an estimate and it can be wrong.",
 "Having no chest pain symptoms raised the estimate in this model, while no chest pain on exercise and a small ST change on the exercise test lowered it.",
 "A heart-friendly diet with vegetables, fruit, whole grains and fish is a good choice.",
 "Aim for moderate activity such as walking or swimming for about 30 minutes on most days.",
 "Avoid tobacco and limit alcohol. Have your blood pressure of 140 checked again.",
 "Please see a doctor in the coming weeks to go over these results. Seek emergency help for chest pain or breathlessness.")
add('C09',"Your estimated chance of heart disease is about 95 percent, which is in the high range. This is only an estimate and it can be wrong, but it is high enough that you should have it checked.",
 "The number of vessels seen on imaging and the ST change on your exercise test raised the estimate. Being female lowered it a little.",
 "Choose vegetables, fruit, whole grains and fish, and keep salt low. Your resting blood pressure was 170.",
 "Until you have seen a doctor, stay with gentle activity such as slow walking, and stop if you feel pain or breathless.",
 "Do not smoke and avoid heavy exertion for now. Write down any symptoms you notice.",
 "Please see a doctor soon, ideally within the next few days, and bring these results. If you get chest pain, trouble breathing or fainting, call emergency services right away.")
add('C10',"Your estimated chance of heart disease is about 96 percent, which is in the high range. This is only an estimate and it can be wrong, but it is high enough that you should have it checked.",
 "The number of vessels seen on imaging, chest pain brought on by exercise, and the ST change on your exercise test all raised the estimate.",
 "Eat a light heart-friendly diet with vegetables, fruit, whole grains and fish, and keep salt and fried food low.",
 "Keep to gentle activity until a doctor has looked at your results. Stop if you feel chest pain or breathless.",
 "Do not smoke and try to rest well. Note when your chest pain happens and what you were doing.",
 "Please see a doctor soon, ideally within the next few days, and bring these results. If you get chest pain, trouble breathing or fainting, call emergency services right away.")
add('C11',"Your estimated chance of heart disease is about 80 percent, which is in the high range. This is only an estimate and it can be wrong, but it is high enough that you should have it checked.",
 "Chest pain brought on by exercise, the type of chest pain you reported and being male all raised the estimate.",
 "Choose vegetables, fruit, whole grains and fish, and limit fried and salty food.",
 "Stay with gentle walking for now and avoid hard exercise until a doctor has seen you.",
 "Do not smoke, sleep well and manage stress. Keep a note of when the chest pain on exercise appears.",
 "Please see a doctor soon, ideally within the next few days, and bring these results. If you get chest pain, trouble breathing or fainting, call emergency services right away.")
add('C12',"Your estimated chance of heart disease is about 90 percent, which is in the high range. This is only an estimate and it can be wrong, but it is high enough that you should have it checked.",
 "The number of vessels seen on imaging, the ST change on your exercise test and your thallium stress test result all raised the estimate.",
 "A diet rich in vegetables, fruit, whole grains and fish helps, and keep salt and fried food low.",
 "Stay with light activity such as slow walking until you have seen a doctor.",
 "Do not smoke and limit alcohol. Keep a list of your symptoms to share with the doctor.",
 "Please see a doctor soon, ideally within the next few days, and bring these results. If you get chest pain, trouble breathing or fainting, call emergency services right away.")
json.dump(D,open('drafts_v1.json','w'),indent=1)
