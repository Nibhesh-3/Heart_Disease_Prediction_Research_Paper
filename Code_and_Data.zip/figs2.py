import json, pickle, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from common import *
plt.rcParams['font.family']='serif'; plt.rcParams['font.serif']=['Liberation Serif','Times New Roman']
S=json.load(open('summary.json')); L=json.load(open('loco.json')); A=json.load(open('ablate_shap.json'))
raw,D=load(); y=D.target.values
def save(n): plt.savefig('f2/'+n,bbox_inches='tight',pad_inches=.04,dpi=300); plt.close()
def clean(ax):
    for s in ('top','right'): ax.spines[s].set_visible(False)
# ---- perf
names={'LRll':'LR (log-loss tuned)','LR':'LR (AUC tuned)','SVM':'SVM (RBF)','XGB':'XGBoost','RF':'Random forest','kNN':'k-NN','GB':'Gradient boosting','GNB':'Naive Bayes','DT':'Decision tree'}
order=['LRll','LR','SVM','XGB','RF','kNN','GB','GNB','DT']
fig,ax=plt.subplots(figsize=(3.5,2.7),dpi=300)
for i,m in enumerate(order[::-1]):
    a,s=S['perf'][m]['auc']; ax.errorbar(a,i,xerr=s,fmt='o',color='black',ms=4,capsize=2,lw=.9,mfc='black' if m=='LRll' else 'white')
ax.set_yticks(range(len(order))); ax.set_yticklabels([names[m] for m in order[::-1]],fontsize=6.5); ax.set_xlabel('AUC (mean \u00b1 SD over 50 outer folds)',fontsize=7); ax.tick_params(axis='x',labelsize=6.5); ax.grid(axis='x',alpha=.3,color='black',lw=.4); clean(ax)
plt.tight_layout(); save('perf.png')
# ---- calibration
rel=S['rel']; fig,ax=plt.subplots(figsize=(3.3,3.2),dpi=300)
ax.plot([0,1],[0,1],color='black',lw=.7,ls=':')
sty={'LRll':('k-','o'),'LR':('k--','s'),'XGB':('k-.','^'),'RF':('k:','D'),'GNB':('0.5','x')}
for m,(ls,mk) in sty.items():
    x=[r[0] for r in rel[m]]; yy=[r[1] for r in rel[m]]
    ax.plot(x,yy,ls,marker=mk,ms=3.2,lw=.9,mfc='white',label=names[m])
ax.set_xlabel('Mean predicted probability',fontsize=7); ax.set_ylabel('Observed fraction positive',fontsize=7); ax.tick_params(labelsize=6.5); ax.legend(fontsize=5.8,frameon=False,loc='upper left'); ax.set_xlim(0,1); ax.set_ylim(0,1); clean(ax)
plt.tight_layout(); save('calib.png')
# ---- bands
b=S['bands']['LRll']; fig,ax=plt.subplots(figsize=(3.3,2.3),dpi=300)
lab=['Low','Moderate','High']; obs=[b['bands'][k]['obs'] for k in ['low','moderate','high']]; pred=[b['bands'][k]['mean_pred'] for k in ['low','moderate','high']]; n=[b['bands'][k]['n'] for k in ['low','moderate','high']]
x=np.arange(3); ax.bar(x-.18,obs,.36,color='black',label='Observed fraction positive'); ax.bar(x+.18,pred,.36,color='white',edgecolor='black',hatch='///',label='Mean predicted probability')
for i in range(3): ax.text(i,max(obs[i],pred[i])+.03,f'n = {n[i]}',ha='center',fontsize=6.5)
ax.set_xticks(x); ax.set_xticklabels([f'{lab[0]}\n(p < {b["low"]:.2f})',f'{lab[1]}\n({b["low"]:.2f} to {b["high"]:.2f})',f'{lab[2]}\n(p \u2265 {b["high"]:.2f})'],fontsize=6.5); ax.set_ylim(0,1.05); ax.tick_params(axis='y',labelsize=6.5); ax.legend(fontsize=6,frameon=False,loc='upper left'); clean(ax)
plt.tight_layout(); save('bands.png')
# ---- subgroup forest
sub=S['sub']['LRll']; keys=['sex:female','sex:male','age:<50','age:50-59','age:>=60','centre:cleveland','centre:hungarian','centre:switzerland','centre:va']
lab={'sex:female':'Female','sex:male':'Male','age:<50':'Age < 50','age:50-59':'Age 50 to 59','age:>=60':'Age \u2265 60','centre:cleveland':'Cleveland','centre:hungarian':'Hungary','centre:switzerland':'Switzerland','centre:va':'Long Beach VA'}
fig,ax=plt.subplots(figsize=(3.5,2.7),dpi=300)
for i,k in enumerate(keys[::-1]):
    v=sub[k]; ax.errorbar(v['auc'],i,xerr=[[v['auc']-v['lo']],[v['hi']-v['auc']]],fmt='s',color='black',ms=3.8,capsize=2,lw=.9,mfc='white')
ax.set_yticks(range(len(keys))); ax.set_yticklabels([f"{lab[k]} (n={sub[k]['n']})" for k in keys[::-1]],fontsize=6.5); ax.axvline(S['perf']['LRll']['auc'][0],color='black',ls=':',lw=.7)
ax.set_xlabel('AUC with 95% bootstrap interval',fontsize=7); ax.tick_params(axis='x',labelsize=6.5); ax.grid(axis='x',alpha=.3,color='black',lw=.4); clean(ax)
plt.tight_layout(); save('sub.png')
# ---- LOCO
fig,ax=plt.subplots(figsize=(3.5,2.5),dpi=300)
cs=['cleveland','hungarian','switzerland','va']; cl=['Cleveland','Hungary','Switzerland','Long Beach VA']
mods=[('LR','LR'),('RF','Random forest'),('XGB','XGBoost'),('SVM','SVM')]; hat=['','///','...','xxx']; col=['black','white','#9a9a9a','white']
w=.2
for j,(m,nm) in enumerate(mods):
    ax.bar(np.arange(4)+(j-1.5)*w,[L[m][c]['auc'] for c in cs],w,label=nm,color=col[j],edgecolor='black',hatch=hat[j],lw=.6)
ax.set_xticks(range(4)); ax.set_xticklabels(cl,fontsize=6.5); ax.set_ylim(.5,.95); ax.set_ylabel('AUC on held-out centre',fontsize=7); ax.tick_params(axis='y',labelsize=6.5); ax.legend(fontsize=5.8,ncol=4,frameon=False,loc='upper right'); ax.grid(axis='y',alpha=.3,color='black',lw=.4); ax.set_axisbelow(True); clean(ax)
plt.tight_layout(); save('loco.png')
# ---- SHAP comparison
bl,bx=A['shap_lr'],A['shap_xgb']
names2=sorted(FEATS,key=lambda f:-bl[f]); 
# values only (exclude indicator part): recompute from arrays
a=pickle.load(open('shap_arrays.pkl','rb')); nm=a['names']
def vals_only(sv):
    m=np.abs(sv).mean(0); return {f:float(m[nm.index(f)]) for f in FEATS}, float(sum(m[i] for i,n_ in enumerate(nm) if n_.endswith('_missing')))
vl,il=vals_only(a['sv_lr']); vx,ix=vals_only(a['sv_x'])
json.dump(dict(vl=vl,vx=vx,il=il,ix=ix),open('shap_vals.json','w'))
order2=sorted(FEATS,key=lambda f:-vl[f])
fig,ax=plt.subplots(figsize=(3.5,3.1),dpi=300); yy=np.arange(len(order2))[::-1]
ax.barh(yy+.2,[vl[f] for f in order2],.4,color='black',label='Logistic regression'); ax.barh(yy-.2,[vx[f] for f in order2],.4,color='white',edgecolor='black',hatch='///',label='XGBoost')
ax.set_yticks(yy); ax.set_yticklabels(order2,fontsize=6.5); ax.set_xlabel('Mean |SHAP value| (log-odds, measured values only)',fontsize=7); ax.tick_params(axis='x',labelsize=6.5); ax.legend(fontsize=6,frameon=False,loc='lower right'); clean(ax)
plt.tight_layout(); save('shap.png')
# ---- ablation
ab=A['ablation']; order3=sorted(FEATS,key=lambda f:ab[f]['delta'])
fig,ax=plt.subplots(figsize=(3.5,3.0),dpi=300); yy=np.arange(13)[::-1]
ax.barh(yy,[ab[f]['delta'] for f in order3],.6,color=['black' if ab[f]['p']<0.05 else 'white' for f in order3],edgecolor='black',lw=.6)
ax.set_yticks(yy); ax.set_yticklabels(order3,fontsize=6.5); ax.set_xlabel('Change in AUC when the predictor is removed',fontsize=7); ax.tick_params(axis='x',labelsize=6.5); ax.axvline(0,color='black',lw=.6); clean(ax)
plt.tight_layout(); save('ablate.png')
# ---- corr (pairwise, observed values)
C=D[FEATS].corr(min_periods=30).values
fig,ax=plt.subplots(figsize=(3.5,3.3),dpi=300); im=ax.imshow(np.abs(C),cmap='Greys',vmin=0,vmax=1)
ax.set_xticks(range(13)); ax.set_yticks(range(13)); ax.set_xticklabels(FEATS,rotation=60,ha='right',fontsize=6); ax.set_yticklabels(FEATS,fontsize=6)
for i in range(13):
    for j in range(13): ax.text(j,i,f'{C[i,j]:.2f}'.replace('-0.00','0.00'),ha='center',va='center',fontsize=3.8,color='white' if abs(C[i,j])>.5 else 'black')
cb=plt.colorbar(im,fraction=.046,pad=.03); cb.ax.tick_params(labelsize=6); cb.set_label('absolute Pearson r',fontsize=6); plt.tight_layout(); save('corr.png')
np.save('corr.npy',C)
# ---- workflow
def box(ax,x,y,w,h,t,fc='white',fs=6.5):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='square,pad=0',fc=fc,ec='black',lw=.9)); ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,linespacing=1.2)
def arr(ax,x1,y1,x2,y2): ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='-|>',color='black',lw=.9,shrinkA=0,shrinkB=0))
steps=['1  Build dataset\nfour UCI files, 920 records, 2 duplicates removed','2  Clean\nzero cholesterol or pressure set to missing','3  Nested cross-validation (10 x 5)\nimputation and scaling fitted inside each fold','4  Tune\ninner 3-fold grid search, equal budget per model','5  Evaluate\nAUC, F1, Brier, accuracy, sensitivity, specificity','6  Calibrate and set risk bands\nfrom out-of-fold probabilities','7  Validate further\nleave-one-centre-out, subgroups, reduced features','8  Explain\nSHAP, exact contributions, predictor removal']
fig,ax=plt.subplots(figsize=(3.5,5.0),dpi=300); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
n=len(steps); h=.085; gap=(1-n*h)/n
for i,t in enumerate(steps):
    yb=1-(i+1)*(h+gap)+gap*.5; box(ax,.04,yb,.92,h,t,fc='#e6e6e6' if i in (0,n-1) else 'white')
    if i<n-1: arr(ax,.5,yb,.5,yb-gap)
save('workflow.png')
print('figs done')
