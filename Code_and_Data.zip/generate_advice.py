"""Generate the advice drafts with the DeepSeek API and run the safety checks.
Usage:  export DEEPSEEK_API_KEY=...   then   python generate_advice.py
Reads results/cases.json, writes results/drafts_deepseek.json and results/checks_deepseek.json.
Note: this script was written for the project repository; run it once with your own key."""
import os, json, re, time, requests
from llm_module import build_prompt, check, FIELDS
KEY=os.environ['DEEPSEEK_API_KEY']; URL='https://api.deepseek.com/chat/completions'
cases=json.load(open('results/cases.json'))
for c in cases: c['top']=[tuple(t) for t in c['top']]
def ask(prompt):
    body={'model':'deepseek-chat','temperature':0.2,'response_format':{'type':'json_object'},
          'messages':[{'role':'system','content':'Return only a JSON object with the keys summary, factors, diet, activity, lifestyle, seek_care, disclaimer.'},{'role':'user','content':prompt}]}
    r=requests.post(URL,headers={'Authorization':'Bearer '+KEY},json=body,timeout=60); r.raise_for_status()
    return json.loads(r.json()['choices'][0]['message']['content'])
FALLBACK={'summary':'We could not produce advice for this result. This is only an estimate and it can be wrong.','factors':'','diet':'','activity':'','lifestyle':'','seek_care':'Please talk to a doctor about this result.','disclaimer':'This is general health information and not a substitute for advice from a doctor.'}
drafts={}; checks={}
for c in cases:
    for attempt in range(3):
        d=ask(build_prompt(c)); r=check(d,c)
        if all(r.values()): break
        time.sleep(1)
    drafts[c['id']]=d if all(r.values()) else FALLBACK; checks[c['id']]=dict(passed=all(r.values()),attempts=attempt+1,detail=r)
json.dump(drafts,open('results/drafts_deepseek.json','w'),indent=1); json.dump(checks,open('results/checks_deepseek.json','w'),indent=1)
print('passed first or after retry:',sum(v['passed'] for v in checks.values()),'of',len(cases))
