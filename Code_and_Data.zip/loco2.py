import json
from common import *
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.metrics import roc_auc_score, f1_score, accuracy_score, recall_score, brier_score_loss, confusion_matrix
raw,D=load(); X=D[FEATS].values; y=D.target.values; cen=D.centre.values
out={}
for name in ['LRll','LRni']:
    out[name]={}
    for c in ['cleveland','hungarian','switzerland','va']:
        te=cen==c; tr=~te
        pipe,grid=make(name)
        g=GridSearchCV(pipe,grid,cv=StratifiedKFold(3,shuffle=True,random_state=7),scoring=('neg_log_loss' if name=='LRll' else 'roc_auc'),n_jobs=1).fit(X[tr],y[tr])
        p=g.predict_proba(X[te])[:,1]; pr=(p>=.5).astype(int); tn,fp,fn,tp=confusion_matrix(y[te],pr,labels=[0,1]).ravel()
        out[name][c]=dict(n=int(te.sum()),pos=int(y[te].sum()),auc=roc_auc_score(y[te],p),f1=f1_score(y[te],pr),acc=accuracy_score(y[te],pr),sens=recall_score(y[te],pr),spec=tn/(tn+fp),brier=brier_score_loss(y[te],p),meanp=float(p.mean()))
    print(name,{c:round(v['auc'],3) for c,v in out[name].items()},flush=True)
json.dump(out,open('loco2.json','w'))
