import json, pickle, numpy as np
from common import *
from llm_module import *
raw,D=load(); X=D[FEATS].values; y=D.target.values
R=pickle.load(open('res_full_LRll.pkl','rb')); pbar=R['oof'].mean(0)
S=json.load(open('summary.json')); lo,hi=S['bands']['LRll']['low'],S['bands']['LRll']['high']
A=json.load(open('ablate_shap.json')); C=A['modalC']
pipe=Pipeline([('imp',SimpleImputer(strategy='median',add_indicator=True)),('sc',StandardScaler()),('m',LogisticRegression(C=C,max_iter=2000))]).fit(X,y)
Z=pipe[:-1].transform(X); w=pipe.named_steps['m'].coef_[0]; names=A['names']
CP={1:'typical angina',2:'atypical angina',3:'non-anginal pain',4:'no chest pain symptoms'}
rng=np.random.default_rng(11); cases=[]
core=['age','sex','cp','trestbps','chol','thalach','exang','oldpeak']; ok=D[core].notna().all(axis=1).values
bands=np.array([band(p,lo,hi) for p in pbar])
for b in ['low','moderate','high']:
    idx=np.where((bands==b)&ok)[0]; 
    fem=[i for i in idx if D.sex[i]==0]; mal=[i for i in idx if D.sex[i]==1]
    pick=list(rng.choice(fem,1,replace=False))+list(rng.choice(mal,3,replace=False)) if len(fem)>=1 else list(rng.choice(idx,4,replace=False))
    for i in pick:
        contrib={names[j]:float(w[j]*Z[i,j]) for j in range(len(names)) if not names[j].endswith('_missing') and D[names[j]].notna()[i]}
        top=sorted(contrib.items(),key=lambda kv:-abs(kv[1]))[:3]
        r=D.iloc[i]
        prof={'age':int(r.age),'sex':'male' if r.sex==1 else 'female','type of chest pain':CP[int(r.cp)],'resting blood pressure':int(r.trestbps),'cholesterol':int(r.chol),'maximum heart rate':int(r.thalach),'chest pain on exercise':'yes' if r.exang==1 else 'no'}
        cases.append(dict(id=f'C{len(cases)+1:02d}',record=int(i),p=float(pbar[i]),band=b,observed_label=int(y[i]),top=[(k,'raises' if v>0 else 'lowers') for k,v in top],top_contrib=[(k,round(v,3)) for k,v in top],profile=prof))
json.dump(cases,open('cases.json','w'),indent=1)
for c in cases:
    print(c['id'],c['band'],f"p={c['p']:.2f}",c['profile'],c['top'])
print(build_prompt({**cases[0],'top':[(k,d) for k,d in cases[0]['top']]})[:1200])
