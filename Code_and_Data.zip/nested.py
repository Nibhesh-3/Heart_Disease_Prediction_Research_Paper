import time, json, pickle, sys
from common import *
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.metrics import roc_auc_score, f1_score, accuracy_score, precision_score, recall_score, brier_score_loss, confusion_matrix
raw,D=load(); X=D[FEATS].values; y=D.target.values; n=len(y)
REP=10; models=sys.argv[1].split(',') ; feats_variant=sys.argv[2] if len(sys.argv)>2 else 'full'
drop={'full':[], 'noca_thal':['ca','thal'], 'noca_thal_slope':['ca','thal','slope']}[feats_variant]
keep=[i for i,f in enumerate(FEATS) if f not in drop]; Xv=X[:,keep]
def metr(yt,p):
    pr=(p>=0.5).astype(int); tn,fp,fn,tp=confusion_matrix(yt,pr,labels=[0,1]).ravel()
    return dict(auc=roc_auc_score(yt,p),f1=f1_score(yt,pr),acc=accuracy_score(yt,pr),prec=precision_score(yt,pr,zero_division=0),rec=recall_score(yt,pr),spec=tn/(tn+fp),brier=brier_score_loss(yt,p))
for name in models:
    t0=time.time(); rows=[]; oof=np.zeros((REP,n)); params=[]
    for r in range(REP):
        skf=StratifiedKFold(5,shuffle=True,random_state=100+r)
        for f,(tr,te) in enumerate(skf.split(Xv,y)):
            pipe,grid=make(name)
            g=GridSearchCV(pipe,grid,cv=StratifiedKFold(3,shuffle=True,random_state=200+r*5+f),scoring=('neg_log_loss' if name=='LRll' else 'roc_auc'),n_jobs=1).fit(Xv[tr],y[tr])
            p=g.predict_proba(Xv[te])[:,1]; oof[r,te]=p
            m=metr(y[te],p); m.update(rep=r,fold=f); rows.append(m); params.append({k:str(v) for k,v in g.best_params_.items()})
        print(name,feats_variant,'rep',r,round(time.time()-t0),'s',flush=True)
    pickle.dump(dict(rows=rows,oof=oof,params=params),open(f'res_{feats_variant}_{name}.pkl','wb'))
    df=pd.DataFrame(rows); print(name,df[['auc','f1','acc','brier']].mean().round(4).to_dict(),flush=True)
