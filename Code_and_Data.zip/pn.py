import json, pickle, numpy as np, pandas as pd, math
from common import *
raw,D=load(); y=D.target.values
S=json.load(open('summary.json')); L=json.load(open('loco.json')); L2=json.load(open('loco2.json'))
def wil(k,n,z=1.96):
    p=k/n; c=(p+z*z/(2*n))/(1+z*z/n); h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n); return [c-h,c+h]
P={}
# bands
R=pickle.load(open('res_full_LRll.pkl','rb')); pbar=R['oof'].mean(0); lo,hi=S['bands']['LRll']['low'],S['bands']['LRll']['high']
grp=np.where(pbar<lo,'low',np.where(pbar>=hi,'high','moderate')); B={}
for g in ['low','moderate','high']:
    m=grp==g; k=int(y[m].sum()); n=int(m.sum()); B[g]=dict(n=n,pos=k,obs=k/n,ci=wil(k,n),mean_pred=float(pbar[m].mean()))
hiflag=pbar>=hi; lowflag=pbar<lo
P['bands']=dict(lo=lo,hi=hi,groups=B,sens_hi=float((hiflag&(y==1)).sum()/(y==1).sum()),spec_hi=float((~hiflag&(y==0)).sum()/(y==0).sum()),ppv_hi=float(y[hiflag].mean()),npv_lo=float(1-y[lowflag].mean()),
  ruleout_share=float(lowflag.mean()),sens_lo_cut=float(((~lowflag)&(y==1)).sum()/(y==1).sum()))
yt=S['youden_LRll']; thr=yt[1]; pr=pbar>=thr
P['youden']=dict(j=yt[0],t=thr,sens=float((pr&(y==1)).sum()/(y==1).sum()),spec=float((~pr&(y==0)).sum()/(y==0).sum()))
# centre table
P['centres']=[dict(c=c,n=int((D.centre==c).sum()),pos=int(D.target[D.centre==c].sum()),age=float(D.age[D.centre==c].mean()),male=float(D.sex[D.centre==c].mean())) for c in ['cleveland','hungarian','switzerland','va']]
P['missing']={c:{f:float(D[f][D.centre==c].isna().mean()*100) for f in ['trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal']} for c in ['cleveland','hungarian','switzerland','va']}
P['missing_all']={f:float(D[f].isna().mean()*100) for f in FEATS}
P['desc']={f:dict(n=int(D[f].notna().sum()),mean=float(D[f].mean()),sd=float(D[f].std()),mn=float(D[f].min()),mx=float(D[f].max())) for f in FEATS}
# loco mean auc
loco={}
for m in L: loco[m]={c:L[m][c]['auc'] for c in L[m]}
for m in L2: loco[m]={c:L2[m][c]['auc'] for c in L2[m]}
P['loco']={m:dict(per=loco[m],mean=float(np.mean(list(loco[m].values())))) for m in loco}
P['loco_full']={'LRll':L2['LRll'],'XGB':L['XGB'],'RF':L['RF']}
# cleveland+hungary mean vs swiss+va
P['n_dedup']=len(D)
json.dump(P,open('paper_numbers.json','w'),indent=1,default=float)
print(json.dumps({k:P[k] for k in ['bands','youden']},indent=1)[:1500]); print({m:round(v['mean'],3) for m,v in P['loco'].items()})
E=None
