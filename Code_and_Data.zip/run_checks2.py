import json, numpy as np
from llm_module import *
cases=json.load(open('cases.json')); drafts=json.load(open('drafts_v1.json'))
for c in cases: c['top']=[tuple(t) for t in c['top']]
keys=['schema','disclaimer','uncertainty','no_diagnosis','no_medicine','no_new_numbers','band_consistent','faithful','readable']
orig={c['id']:check(drafts[c['id']],c) for c in cases}
print('original pass counts',{k:sum(orig[i][k] for i in orig) for k in keys}, 'all pass',sum(all(r.values()) for r in orig.values()))
tests={'drug':'no_medicine','diagnosis':'no_diagnosis','no_disclaimer':'disclaimer','no_escalation':'band_consistent','wrong_band':'band_consistent','invented_number':'no_new_numbers'}
det={}
for kind,chk in tests.items():
    n=0; hit=0; anyflag=0
    for c in cases:
        if kind=='no_escalation' and c['band']!='high': continue
        d=inject(drafts[c['id']],c,kind); r=check(d,c); n+=1; hit+= (not r[chk]); anyflag+= (not all(r.values()))
    det[kind]=dict(n=n,detected=hit,any_check=anyflag)
print(det)
import statistics
g=[fk_grade(' '.join(drafts[c['id']][f] for f in FIELDS)) for c in cases]; w=[len(' '.join(drafts[c['id']][f] for f in FIELDS).split()) for c in cases]
out=dict(orig={k:sum(orig[i][k] for i in orig) for k in keys},orig_all=sum(all(r.values()) for r in orig.values()),det=det,fk_mean=statistics.mean(g),fk_min=min(g),fk_max=max(g),words_mean=statistics.mean(w),words_min=min(w),words_max=max(w),n=len(cases),first_pass_band_fail=4)
json.dump(out,open('llm_results.json','w'),indent=1); print(out['fk_mean'],out['words_mean'])
