"""Run the nine automatic checks and the injection test on the DeepSeek drafts.
Usage: python run_checks_deepseek.py [drafts.json]   (default: results/drafts_deepseek.json)
Writes results/llm_results_deepseek.json, which has the same layout as results/llm_results.json."""
import json, sys, statistics
from llm_module import check, inject, fk_grade, FIELDS
path=sys.argv[1] if len(sys.argv)>1 else 'results/drafts_deepseek.json'
cases=json.load(open('results/cases.json')); drafts=json.load(open(path))
for c in cases: c['top']=[tuple(t) for t in c['top']]
keys=['schema','disclaimer','uncertainty','no_diagnosis','no_medicine','no_new_numbers','band_consistent','faithful','readable']
orig={c['id']:check(drafts[c['id']],c) for c in cases}
tests={'drug':'no_medicine','diagnosis':'no_diagnosis','no_disclaimer':'disclaimer','no_escalation':'band_consistent','wrong_band':'band_consistent','invented_number':'no_new_numbers'}
det={}
for kind,chk in tests.items():
    n=hit=anyf=0
    for c in cases:
        if kind=='no_escalation' and c['band']!='high': continue
        r=check(inject(drafts[c['id']],c,kind),c); n+=1; hit+=(not r[chk]); anyf+=(not all(r.values()))
    det[kind]=dict(n=n,detected=hit,any_check=anyf)
txt=lambda c:' '.join(drafts[c['id']][f] for f in FIELDS)
g=[fk_grade(txt(c)) for c in cases]; w=[len(txt(c).split()) for c in cases]
out=dict(orig={k:sum(orig[i][k] for i in orig) for k in keys},orig_all=sum(all(r.values()) for r in orig.values()),det=det,fk_mean=statistics.mean(g),fk_min=min(g),fk_max=max(g),words_mean=statistics.mean(w),words_min=min(w),words_max=max(w),n=len(cases),failed_cases={i:[k for k in keys if not r[k]] for i,r in orig.items() if not all(r.values())})
json.dump(out,open('results/llm_results_deepseek.json','w'),indent=1); print(json.dumps(out,indent=1))
