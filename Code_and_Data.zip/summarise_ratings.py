"""Summarise the clinician rating sheet (results/reviewer_rating_sheet.csv) once it has been filled in.
Ratings are integers 1 to 5 in the columns R1_* and R2_* (rater 1 and rater 2)."""
import pandas as pd, numpy as np, json
from scipy.stats import spearmanr
df=pd.read_csv('results/reviewer_rating_sheet.csv'); crit=['correctness','safety','consistency','specificity','clarity','calibration']
out={}
for c in crit:
    a=df[f'R1_{c}'].astype(float); b=df[f'R2_{c}'].astype(float)
    out[c]=dict(mean_r1=float(a.mean()),mean_r2=float(b.mean()),mean_all=float(pd.concat([a,b]).mean()),share_4_or_5=float((pd.concat([a,b])>=4).mean()),exact_agreement=float((a==b).mean()),within_one=float((abs(a-b)<=1).mean()),spearman=float(spearmanr(a,b).statistic) if a.nunique()>1 and b.nunique()>1 else None,min_rating=int(min(a.min(),b.min())))
json.dump(out,open('results/rating_summary.json','w'),indent=1); print(pd.DataFrame(out).T.round(2).to_string())
